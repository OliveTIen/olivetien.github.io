#pragma once

//using myfloat = float;

#include "../../gpu/datatype/DefineType.h"