#ifndef EXACT_SOLUTION_WRITER_H
#define EXACT_SOLUTION_WRITER_H


// 不属于U2NITS体系，无需加namespace
class ExactSolutionWriter {
public:
	static void calculateShockTube1D();


};

#endif // !EXACT_SOLUTION_WRITER_H
