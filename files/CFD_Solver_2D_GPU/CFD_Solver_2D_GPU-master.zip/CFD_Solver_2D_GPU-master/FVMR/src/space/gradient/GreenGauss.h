#ifndef GRADIENT_GREENGAUSS_H
#define GRADIENT_GREENGAUSS_H
#include "../../gpu/datatype/DefineType.h"
namespace U2NITS {
	namespace Space {
		namespace Gradient {

		}
	}
}

#endif // !GRADIENT_GREENGAUSS_H

