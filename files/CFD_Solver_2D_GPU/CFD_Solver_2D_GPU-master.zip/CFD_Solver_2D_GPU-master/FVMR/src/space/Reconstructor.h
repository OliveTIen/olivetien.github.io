#ifndef RECONSTRUCTOR_H
#define RECONSTRUCTOR_H
/**
* 遗留代码，线性重构
* 参照Laminar-WangQ，reconstruction_initialize.f90
*/
class FVM_2D;
class Element_2D;

class Reconstructor {
public:

private:
	
};


#endif // !RECONSTRUCTOR_H