#ifndef _CONVECTION_GPU_H_
#define _CONVECTION_GPU_H_

#include "LocalLaxFriedrichsGPU.h"
#include "RoeGPU.h"

#endif // !_CONVECTION_GPU_H_
