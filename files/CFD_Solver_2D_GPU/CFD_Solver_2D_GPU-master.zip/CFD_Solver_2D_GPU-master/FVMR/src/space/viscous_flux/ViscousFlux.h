#ifndef VISCOUS_FLUX_H
#define VISCOUS_FLUX_H
#include "../../gpu/datatype/DefineType.h"

namespace U2NITS {
	namespace Space {
		void edge_viscous_flux();
	}
}

#endif // !VISCOUS_FLUX_H
