#ifndef _MATH_GPU_H_
#define _MATH_GPU_H_

#include "CommonValue.h"
#include "BasicAlgorithmGPU.h"
#include "MatrixKernelGPU.h"
#include "PhysicalKernelGPU.h"

#endif 
