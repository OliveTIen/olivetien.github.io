
#ifndef _CEQUATION_H_
#define _CEQUATION_H_

namespace U2NITS {
    
    class CEquation {
    public:
        
    };
}


#endif