
#ifndef _CPLATFORM_H_
#define _CPLATFORM_H_

namespace U2NITS {

    class CPlatform {
    public:

    };
}


#endif