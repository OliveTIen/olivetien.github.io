#include "CEulerSolver.h"

void U2NITS::CEulerSolver::initialize() {
}

void U2NITS::CEulerSolver::solve() {
}

void U2NITS::CEulerSolver::updateResidual() {
}

void U2NITS::CEulerSolver::finalize() {
}
