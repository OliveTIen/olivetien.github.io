#ifndef GEOMETRY_READER_H
#define GEOMETRY_READER_H

class GeometryReader {

public:
	/*旧网格读取；初始化pTable；初始化边界几何*/
};

#endif