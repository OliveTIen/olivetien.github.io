#ifndef _DATATYPE_H_
#define _DATATYPE_H_

#include "BoundarySetMap.h"
#include "EdgeSoA.h"
#include "ElementSoA.h"
#include "FieldSoA.h"
#include "NodeSoA.h"
#include "DeviceData.h"

#endif // !_DATATYPE_H_
