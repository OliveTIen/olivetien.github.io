#include "JsonFileManager.h"
#include "output/LogWriter.h"
#include "global/FilePathManager.h"

void JsonFileManager::useDefaultInputPara_and_writeInputPara() {
	LogWriter::writeLogAndCout("use default file: input.json\n");
	inputpara.SetObject();
	rapidjson::Document::AllocatorType& allocator = inputpara.GetAllocator();

	rapidjson::Value basic(rapidjson::kObjectType);
	basic.AddMember("dimension", 2, allocator);
	basic.AddMember("continue", 1, allocator);
	basic.AddMember("filename", "default_filename", allocator);
	inputpara.AddMember("basic", basic, allocator);//��Ҫ��basic.AddMember֮��ʹ�ã����򱨴�

	rapidjson::Value space(rapidjson::kObjectType);
	rapidjson::Value space_1D(rapidjson::kObjectType);
	space_1D.AddMember("nElement", 300, allocator);
	space_1D.AddMember("x1", 0.0, allocator);
	space_1D.AddMember("x2", 1.0, allocator);
	rapidjson::Value space_2D(rapidjson::kObjectType);
	space.AddMember("space_1D", space_1D, allocator);
	space.AddMember("space_2D", space_2D, allocator);
	inputpara.AddMember("space", space, allocator);

	rapidjson::Value time(rapidjson::kObjectType);
	time.AddMember("CFL", 0.6, allocator);
	time.AddMember("T", 0.01, allocator);
	inputpara.AddMember("time", time, allocator);

	rapidjson::Value physicsModel(rapidjson::kObjectType);
	physicsModel.AddMember("gamma", 1.4, allocator);
	physicsModel.AddMember("equation:1-Eluer,2-NS", 1, allocator);
	inputpara.AddMember("physicsModel", physicsModel, allocator);

	rapidjson::Value boundaryCondition(rapidjson::kObjectType);
	rapidjson::Value bC_1D(rapidjson::kObjectType);
	rapidjson::Value bC_2D(rapidjson::kObjectType);
	rapidjson::Value bC_2D_inlet(rapidjson::kObjectType);
	bC_2D_inlet.AddMember("rho", 1.0, allocator);
	bC_2D_inlet.AddMember("u", 500.0, allocator);
	bC_2D_inlet.AddMember("v", 0.0, allocator);
	bC_2D_inlet.AddMember("p", 1.1e5, allocator);
	bC_2D_inlet.AddMember("Ma", 0.5, allocator);
	bC_2D_inlet.AddMember("AOA[degree]", 0.0, allocator);
	rapidjson::Value bC_2D_outlet(rapidjson::kObjectType);
	bC_2D_outlet.AddMember("rho", 1.0, allocator);
	bC_2D_outlet.AddMember("u", 300.0, allocator);
	bC_2D_outlet.AddMember("v", 0.0, allocator);
	bC_2D_outlet.AddMember("p", 1.0e5, allocator);
	bC_2D_outlet.AddMember("Ma", 1.5, allocator);
	bC_2D_outlet.AddMember("AOA[degree]", 0.0, allocator);
	rapidjson::Value bC_2D_inf(rapidjson::kObjectType);
	bC_2D_inf.AddMember("rho", 1.0, allocator);
	bC_2D_inf.AddMember("u", 300.0, allocator);
	bC_2D_inf.AddMember("v", 0.0, allocator);
	bC_2D_inf.AddMember("p", 1.0e5, allocator);
	bC_2D_inf.AddMember("Ma", 0.8, allocator);
	bC_2D_inf.AddMember("AOA[degree]", 1.25, allocator);
	bC_2D.AddMember("inlet", bC_2D_inlet, allocator);
	bC_2D.AddMember("outlet", bC_2D_outlet, allocator);
	bC_2D.AddMember("inf", bC_2D_inf, allocator);
	boundaryCondition.AddMember("1D", bC_1D, allocator);
	boundaryCondition.AddMember("2D", bC_2D, allocator);
	inputpara.AddMember("boundaryCondition", boundaryCondition, allocator);

	rapidjson::Value output(rapidjson::kObjectType);
	output.AddMember("step_per_output", 50, allocator);
	rapidjson::Value output_var(rapidjson::kObjectType);
	output_var.AddMember("rho", 1, allocator);
	output_var.AddMember("u", 1, allocator);
	output_var.AddMember("v", 1, allocator);
	output_var.AddMember("p", 1, allocator);
	output.AddMember("output_var:bool", output_var, allocator);
	inputpara.AddMember("output", output, allocator);

	createFolderIfDoesntExist("input");
	writeInputPara(FilePathManager::getInstance()->getExePath_withSlash() + "input\\input.json");

}

void JsonFileManager::writeInputPara(std::string filepath_name) {
	rapidjson::StringBuffer buffer;
	rapidjson::PrettyWriter<rapidjson::StringBuffer> prettyWriter(buffer);  //��ʽ��
	inputpara.Accept(prettyWriter);
	std::string content = buffer.GetString();
	std::ofstream outfile(filepath_name);
	if (outfile.is_open()) {
		outfile << content;
		outfile.close();
		//std::cout << "����ļ����ݣ�\n";
		//std::cout << content;
	}
	else {
		std::cout << "(JsonFileManager::writeInputPara)Error: fail to open " + filepath_name + "\n";
	}
}

void JsonFileManager::readInputPara_initGlobalPara(std::string filepath_name) {
	//��ȡ��ʼ��������ʼ��GlobalPara

	//��ȡ�������������json��
	std::ifstream infile(filepath_name);
	if (infile.is_open()) {
		LogWriter::writeLogAndCout("read input parameter from " + filepath_name + "\n");
		std::string json_content((std::istreambuf_iterator<char>(infile)), std::istreambuf_iterator<char>()); //���ļ���������ת��λstd::string����
		infile.close();
		inputpara.Parse(json_content.c_str());
	}
	else {
		LogWriter::writeLogAndCout("(JsonFileManager::readInputPara)Error: fail to open " + filepath_name + "\n");
		useDefaultInputPara_and_writeInputPara();
	}

	//��json����ʼ��GlobalPara
	useJsonTreeToUpdateGlobalPara();
}

void JsonFileManager::checkIntegrity() {
}

void JsonFileManager::useJsonTreeToUpdateGlobalPara() {
	using namespace GlobalPara;
	const char* err = "Error: Unexisted member, in function JsonFileManager::useJsonTreeToUpdateGlobalPara()\n";
	try {
		std::cout << "basic\n";
		if (inputpara.HasMember("basic")) {
			rapidjson::Value& basic = inputpara["basic"];
			getMemberValue(basic, "dimension", basic::dimension);
			getMemberValue(basic, "continue", basic::_continue);
			getMemberString(basic, "filename", basic::filename);
		}
		else throw err;

		std::cout << "space\n";
		if (inputpara.HasMember("space") && inputpara["space"].HasMember("space_1D")) {
			rapidjson::Value& space_1D = inputpara["space"]["space_1D"];
			getMemberValue<int>(space_1D, "nElement", space::_1D::nElement);
			getMemberValue<double>(space_1D, "x1", space::_1D::x1);
			getMemberValue<double>(space_1D, "x2", space::_1D::x2);
		}
		else throw err;

		std::cout << "time\n";
		if (inputpara.HasMember("time")) {
			rapidjson::Value& time = inputpara["time"];
			getMemberValue(time, "CFL", time::CFL);
			getMemberValue(time, "T", time::T);
		}
		else throw err;

		std::cout << "physicsModel\n";
		if (inputpara.HasMember("physicsModel")) {
			rapidjson::Value& physicsModel = inputpara["physicsModel"];
			getMemberValue(physicsModel, "gamma", Constant::gamma);
			int equation_;
			getMemberValue(physicsModel, "equation:1-Eluer,2-NS", equation_);
			if (equation_ == 1)physicsModel::equation = _EQ_euler;//���ΪphysicsModel
			else if (equation_ == 2)physicsModel::equation = _EQ_NS;
		}
		else throw err;

		std::cout << "boundaryCondition\n";
		if (inputpara.HasMember("boundaryCondition") && inputpara["boundaryCondition"].HasMember("2D")
			&& inputpara["boundaryCondition"]["2D"].HasMember("inlet") && inputpara["boundaryCondition"]["2D"].HasMember("outlet")
			&& inputpara["boundaryCondition"]["2D"].HasMember("inf")
			) {
			rapidjson::Value& boundaryCondition = inputpara["boundaryCondition"];
			getMemberValue(boundaryCondition["2D"]["inlet"], "use ruvp", boundaryCondition::_2D::inlet::use_ruvp);
			getMemberValue(boundaryCondition["2D"]["inlet"], "rho", boundaryCondition::_2D::inlet::ruvp[0]);
			getMemberValue(boundaryCondition["2D"]["inlet"], "u", boundaryCondition::_2D::inlet::ruvp[1]);
			getMemberValue(boundaryCondition["2D"]["inlet"], "v", boundaryCondition::_2D::inlet::ruvp[2]);
			getMemberValue(boundaryCondition["2D"]["inlet"], "p", boundaryCondition::_2D::inlet::ruvp[3]);
			getMemberValue(boundaryCondition["2D"]["inlet"], "Ma", boundaryCondition::_2D::inlet::Ma);
			getMemberValue(boundaryCondition["2D"]["inlet"], "AOA[degree]", boundaryCondition::_2D::inlet::AOA);

			getMemberValue(boundaryCondition["2D"]["outlet"], "use ruvp", boundaryCondition::_2D::outlet::use_ruvp);
			getMemberValue(boundaryCondition["2D"]["outlet"], "rho", boundaryCondition::_2D::outlet::ruvp[0]);
			getMemberValue(boundaryCondition["2D"]["outlet"], "u", boundaryCondition::_2D::outlet::ruvp[1]);
			getMemberValue(boundaryCondition["2D"]["outlet"], "v", boundaryCondition::_2D::outlet::ruvp[2]);
			getMemberValue(boundaryCondition["2D"]["outlet"], "p", boundaryCondition::_2D::outlet::ruvp[3]);
			getMemberValue(boundaryCondition["2D"]["outlet"], "Ma", boundaryCondition::_2D::outlet::Ma);
			getMemberValue(boundaryCondition["2D"]["outlet"], "AOA[degree]", boundaryCondition::_2D::outlet::AOA);

			getMemberValue(boundaryCondition["2D"]["inf"], "use ruvp", boundaryCondition::_2D::inf::use_ruvp);
			getMemberValue(boundaryCondition["2D"]["inf"], "rho", boundaryCondition::_2D::inf::ruvp[0]);
			getMemberValue(boundaryCondition["2D"]["inf"], "u", boundaryCondition::_2D::inf::ruvp[1]);
			getMemberValue(boundaryCondition["2D"]["inf"], "v", boundaryCondition::_2D::inf::ruvp[2]);
			getMemberValue(boundaryCondition["2D"]["inf"], "p", boundaryCondition::_2D::inf::ruvp[3]);
			getMemberValue(boundaryCondition["2D"]["inf"], "Ma", boundaryCondition::_2D::inf::Ma);
			getMemberValue(boundaryCondition["2D"]["inf"], "AOA[degree]", boundaryCondition::_2D::inf::AOA);
		}
		else throw err;

		std::cout << "initialCondition\n";
		if (inputpara.HasMember("initialCondition")) {
			rapidjson::Value& initialCondition = inputpara["initialCondition"];
			getMemberValue(initialCondition, "type", initialCondition::type);
		}
		else throw err;

		std::cout << "output\n";
		if (inputpara.HasMember("output") && inputpara["output"].HasMember("output_var:bool")) {
			rapidjson::Value& output = inputpara["output"];
			getMemberValue(output, "step_per_output", output::step_per_output);
			getMemberValue(output["output_var:bool"], "rho", output::output_var_ruvp[0]);
			getMemberValue(output["output_var:bool"], "u", output::output_var_ruvp[1]);
			getMemberValue(output["output_var:bool"], "v", output::output_var_ruvp[2]);
			getMemberValue(output["output_var:bool"], "p", output::output_var_ruvp[3]);
		}
		else throw err;


	}
	catch (const char* e) {
		LogWriter::writeLogAndCout(e);
	}

}

void JsonFileManager::createFolderIfDoesntExist(std::string foldername) {
	std::string path = FilePathManager::getInstance()->getExePath_withSlash();
	std::vector<std::string> files = FilePathManager::ls(path);
	for (int i = 0; i < files.size(); i++) {
		if (files[i] == foldername)return;//�ļ����Ѿ�����
	}
	foldername = "mkdir " + path + foldername;
	system(foldername.c_str());
}
